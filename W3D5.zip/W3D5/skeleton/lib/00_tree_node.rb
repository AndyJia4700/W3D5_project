class PolyTreeNode
    attr_reader :value, :parent
    attr_accessor :children

    def initialize(value)
        @value = value
        @children = []
        @parent = nil
    end

    def parent=(parent_node)
        old_parent = parent
        new_parent = parent_node

        if old_parent == nil
            @parent = new_parent
            if !self.parent.children.include?(self)
                parent.add_child(self)
            end
        else
            if new_parent == nil
                if self.parent.children.include?(self)
                    self.parent.remove_child(self)
                end
                @parent = nil
            else
                if self.parent.children.include?(self)
                    self.parent.remove_child(self)
                end
                @parent = new_parent
                if !self.parent.children.include?(self)
                    parent.add_child(self)
                end
            end
        end

        # if new_parent == nil || old_parent != nil
        #     parent.remove_child(self)
        #     @parent = new_parent
        #     # if old_parent != nil
        #     #     parent.remove_child(self)
        #     # end
        # else
        #     @parent = new_parent
        #     if !parent.children.include?(self) 
        #         parent.add_child(self)
        #         #delete self.children + parent_node.children
        #     # else
        #     #     raise "not a valid parent"
        #     end
        # end

    end

    def add_child(child_node)
        if !children.include?(child_node)
            self.children << child_node
            if children.last.parent != self
                children.last.parent = self
            end
        else
            raise "not a valid child"
        end
    end

    def remove_child(child_node)
        if self.children.include?(child_node)
            children.reject!{|child_|child_ == child_node}
            child_node.parent = nil
        else
            raise "not valid child"
        end
    end

    # require 'byebug'
    def dfs(target)
        return self if self.value == target
        # return nil if self.children.empty? #####
        
        self.children.each do |level|
            result = level.dfs(target)
            return result if result
        end
        nil
        # if nil == self.children.each do |level|
        #     level.dfs(target)
        #     # return nil if result == nil
        #     end
        #     return nil
        # end
    end

    def bfs(target)
        queue = []

        # if self.value !
        # self.
        #shift off 1st
        #dequeue until result = target
    end
    

end

# @value = ??? @parent =  @child = []
